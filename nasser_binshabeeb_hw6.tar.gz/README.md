# Python_hw6
Apache top 25 errors

A program that goes over an error log file and prints the top 25 most common error pages
